import start as start

start.run_simulation('config_1.json')


